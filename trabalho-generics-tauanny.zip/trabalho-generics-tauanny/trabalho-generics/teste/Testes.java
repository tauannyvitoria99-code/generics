import logistica.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/** Testes simples (sem JUnit) para rodar com apenas o JDK. */
public class Testes {
    private static int ok = 0, falhas = 0;

    private static void verifica(String nome, boolean condicao) {
        if (condicao) { ok++; System.out.println("[OK]    " + nome); }
        else { falhas++; System.out.println("[FALHA] " + nome); }
    }

    public static void main(String[] args) {
        Deposito<Eletronico> dep = new Deposito<>("Eletrônicos");
        verifica("retirar() em depósito vazio devolve Optional.empty()", dep.retirar().isEmpty());

        Eletronico a = new Eletronico("TV", 2000, 110);
        Eletronico b = new Eletronico("Rádio", 150, 220);
        dep.adicionar(a);
        dep.adicionar(b);
        verifica("quantidade() == 2 após duas adições", dep.quantidade() == 2);
        verifica("retirar() segue FIFO", dep.retirar().orElseThrow() == a);

        boolean lancou = false;
        try { dep.adicionar(null); } catch (NullPointerException e) { lancou = true; }
        verifica("adicionar(null) é rejeitado", lancou);

        verifica("buscarPorNome ignora maiúsculas/minúsculas",
                Operacoes.buscarPorNome(dep, "RÁDIO").orElse(null) == b);
        verifica("buscarPorNome inexistente devolve Optional.empty()",
                Operacoes.buscarPorNome(dep, "Geladeira").isEmpty());

        List<Eletronico> copia = dep.listar();
        boolean imutavel = false;
        try { copia.add(a); } catch (UnsupportedOperationException e) { imutavel = true; }
        verifica("listar() devolve cópia imutável", imutavel);

        Deposito<Produto> geral = new Deposito<>("Geral");
        dep.adicionar(a);
        int n = Operacoes.transferir(dep, geral);
        verifica("transferir Deposito<Eletronico> -> Deposito<Produto> move 2 itens", n == 2 && dep.estaVazio() && geral.quantidade() == 2);

        Deposito<Alimento> alim = new Deposito<>("Alimentos");
        alim.adicionar(new Alimento("Arroz", 30, LocalDate.of(2027, 1, 1)));
        alim.adicionar(new Alimento("Feijão", 9, LocalDate.of(2027, 2, 1)));
        alim.adicionar(new Alimento("Leite", 6, LocalDate.of(2026, 12, 1)));
        int parcial = Operacoes.transferir(alim, geral, 2);
        verifica("transferir com limite move só 2 itens", parcial == 2 && alim.quantidade() == 1);

        boolean invalido = false;
        try { new Eletronico(" ", 10, 110); } catch (IllegalArgumentException e) { invalido = true; }
        verifica("Produto com nome em branco é rejeitado", invalido);

        System.out.println("\nResultado: " + ok + " OK, " + falhas + " falha(s)");
        if (falhas > 0) System.exit(1);
    }
}
