import java.util.*;

public class ErroInvariancia {
    public static void main(String[] args) {
        List<String> strings = new ArrayList<>();
        List<Object> objetos = strings;
    }
}
