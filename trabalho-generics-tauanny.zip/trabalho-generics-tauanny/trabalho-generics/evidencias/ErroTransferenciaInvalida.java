import logistica.*;

public class ErroTransferenciaInvalida {
    public static void main(String[] args) {
        Deposito<Eletronico> eletronicos = new Deposito<>("Eletrônicos");
        Deposito<Alimento> alimentos = new Deposito<>("Alimentos");
        Operacoes.transferir(eletronicos, alimentos);
    }
}
