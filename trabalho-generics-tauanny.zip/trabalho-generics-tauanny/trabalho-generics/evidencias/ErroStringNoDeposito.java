import logistica.*;

public class ErroStringNoDeposito {
    public static void main(String[] args) {
        Deposito<String> d = new Deposito<>("Inválido");
    }
}
