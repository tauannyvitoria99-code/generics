import java.util.*;

public class ErroInstanceof {
    public static void main(String[] args) {
        Object o = new ArrayList<String>();
        if (o instanceof List<String>) {
            System.out.println("lista de String");
        }
    }
}
