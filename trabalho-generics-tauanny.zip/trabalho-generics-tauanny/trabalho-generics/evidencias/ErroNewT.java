public class ErroNewT<T> {
    T criar() {
        return new T();
    }
}
