import logistica.*;
import java.time.LocalDate;

public class ErroAlimentoEmEletronicos {
    public static void main(String[] args) {
        Deposito<Eletronico> depositoEletronicos = new Deposito<>("Eletrônicos");
        depositoEletronicos.adicionar(new Alimento("Arroz 5kg", 29.9, LocalDate.of(2027, 1, 10)));
    }
}
