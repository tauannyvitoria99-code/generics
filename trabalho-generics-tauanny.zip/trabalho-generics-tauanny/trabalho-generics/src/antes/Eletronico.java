package antes;

/** Versão ORIGINAL (sem superclasse comum). */
public class Eletronico {
    private final String nome;

    public Eletronico(String nome) { this.nome = nome; }

    public String getNome() { return nome; }

    @Override
    public String toString() { return "Eletronico[" + nome + "]"; }
}
