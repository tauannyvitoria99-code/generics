package antes;

/** Versão ORIGINAL (sem superclasse comum). */
public class Vestuario {
    private final String nome;

    public Vestuario(String nome) { this.nome = nome; }

    public String getNome() { return nome; }

    @Override
    public String toString() { return "Vestuario[" + nome + "]"; }
}
