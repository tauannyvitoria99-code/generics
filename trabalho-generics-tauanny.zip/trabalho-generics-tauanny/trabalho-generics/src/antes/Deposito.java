package antes;

import java.util.ArrayList;
import java.util.List;

/**
 * Versão ORIGINAL (problemática) do depósito do estagiário:
 * guarda "qualquer coisa" (Object) e devolve null quando está vazio.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class Deposito {
    private final List itens = new ArrayList(); // raw type

    public void adicionar(Object produto) {
        itens.add(produto);
    }

    public Object retirar() {
        if (itens.isEmpty()) {
            return null;
        }
        return itens.remove(0);
    }

    public int quantidade() { return itens.size(); }
}
