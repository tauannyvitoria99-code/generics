package antes;

/** Demonstra os problemas do código original em tempo de execução. */
public class MainAntes {
    public static void main(String[] args) {
        Deposito depositoEletronicos = new Deposito();
        depositoEletronicos.adicionar(new Eletronico("Notebook"));
        depositoEletronicos.adicionar(new Alimento("Arroz 5kg"));   // erro do operador: compila!
        depositoEletronicos.adicionar("Uma String qualquer");       // qualquer coisa entra: compila!

        System.out.println("Itens no depósito de eletrônicos: " + depositoEletronicos.quantidade());

        // 1) Retirada com cast obrigatório
        Eletronico e1 = (Eletronico) depositoEletronicos.retirar();
        System.out.println("Retirado 1: " + e1);

        try {
            Eletronico e2 = (Eletronico) depositoEletronicos.retirar(); // era um Alimento!
            System.out.println("Retirado 2: " + e2);
        } catch (ClassCastException ex) {
            System.out.println("ERRO EM EXECUÇÃO -> " + ex);
        }

        // 2) Depósito vazio devolve null -> NullPointerException mais adiante
        Deposito vazio = new Deposito();
        try {
            Eletronico e3 = (Eletronico) vazio.retirar();
            System.out.println("Nome: " + e3.getNome());
        } catch (NullPointerException ex) {
            System.out.println("ERRO EM EXECUÇÃO -> NullPointerException (retirar() devolveu null)");
        }
    }
}
