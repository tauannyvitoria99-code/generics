package antes;

/** Versão ORIGINAL (sem superclasse comum). */
public class Alimento {
    private final String nome;

    public Alimento(String nome) { this.nome = nome; }

    public String getNome() { return nome; }

    @Override
    public String toString() { return "Alimento[" + nome + "]"; }
}
