package logistica;

public class Eletronico extends Produto {
    private final int voltagem;

    public Eletronico(String nome, double preco, int voltagem) {
        super(nome, preco);
        this.voltagem = voltagem;
    }

    public int getVoltagem() { return voltagem; }
}
