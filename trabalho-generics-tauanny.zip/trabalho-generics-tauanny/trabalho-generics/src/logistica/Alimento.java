package logistica;

import java.time.LocalDate;

public class Alimento extends Produto {
    private final LocalDate validade;

    public Alimento(String nome, double preco, LocalDate validade) {
        super(nome, preco);
        this.validade = validade;
    }

    public LocalDate getValidade() { return validade; }
}
