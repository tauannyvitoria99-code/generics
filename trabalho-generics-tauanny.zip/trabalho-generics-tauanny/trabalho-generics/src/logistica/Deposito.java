package logistica;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Depósito genérico com tipo limitado: só aceita subtipos de {@link Produto}.
 * Deposito&lt;Eletronico&gt; só guarda Eletronico; Deposito&lt;String&gt; nem compila.
 */
public class Deposito<T extends Produto> {
    private final String nome;
    private final Deque<T> itens = new ArrayDeque<>();

    public Deposito(String nome) {
        this.nome = Objects.requireNonNull(nome, "O nome do depósito é obrigatório");
    }

    public String getNome() { return nome; }

    public void adicionar(T item) {
        itens.addLast(Objects.requireNonNull(item, "Não é possível armazenar null"));
    }

    /** Retira o item mais antigo (FIFO). Vazio => Optional.empty(), nunca null. */
    public Optional<T> retirar() {
        return Optional.ofNullable(itens.pollFirst());
    }

    public int quantidade() { return itens.size(); }

    public boolean estaVazio() { return itens.isEmpty(); }

    /** Cópia imutável do conteúdo atual. */
    public List<T> listar() { return List.copyOf(itens); }
}
