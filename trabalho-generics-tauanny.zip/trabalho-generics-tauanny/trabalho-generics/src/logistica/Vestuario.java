package logistica;

public class Vestuario extends Produto {
    private final String tamanho;

    public Vestuario(String nome, double preco, String tamanho) {
        super(nome, preco);
        this.tamanho = tamanho;
    }

    public String getTamanho() { return tamanho; }
}
