package logistica;

/** Superclasse de todos os produtos armazenáveis. */
public abstract class Produto {
    private final String nome;
    private final double preco;

    protected Produto(String nome, double preco) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome do produto é obrigatório");
        }
        if (preco < 0) {
            throw new IllegalArgumentException("O preço não pode ser negativo");
        }
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() { return nome; }

    public double getPreco() { return preco; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "[nome=" + nome + ", preco=" + String.format("%.2f", preco) + "]";
    }
}
