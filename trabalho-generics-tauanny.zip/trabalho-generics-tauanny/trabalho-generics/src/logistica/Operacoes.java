package logistica;

import java.util.Optional;

/** Métodos genéricos e wildcards que operam sobre depósitos. */
public final class Operacoes {
    private Operacoes() {}

    /** Método genérico: o tipo de retorno acompanha o tipo do depósito. */
    public static <T extends Produto> Optional<T> buscarPorNome(Deposito<T> deposito, String nome) {
        return deposito.listar().stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nome))
                .findFirst();
    }

    /**
     * PECS: a origem é PRODUTORA (extends) e o destino é CONSUMIDOR (super).
     * Move todos os itens e devolve quantos foram transferidos.
     */
    public static <T extends Produto> int transferir(Deposito<? extends T> origem,
                                                     Deposito<? super T> destino) {
        return transferir(origem, destino, Integer.MAX_VALUE);
    }

    /** Move no máximo {@code quantidade} itens. */
    public static <T extends Produto> int transferir(Deposito<? extends T> origem,
                                                     Deposito<? super T> destino,
                                                     int quantidade) {
        int movidos = 0;
        while (movidos < quantidade) {
            Optional<? extends T> item = origem.retirar();
            if (item.isEmpty()) {
                break;
            }
            destino.adicionar(item.get());
            movidos++;
        }
        return movidos;
    }

    /** Wildcard ilimitado: só lê, aceita depósito de qualquer tipo de produto. */
    public static void listarConteudo(Deposito<?> deposito) {
        System.out.println("Depósito '" + deposito.getNome() + "' (" + deposito.quantidade() + " item(ns)):");
        for (Produto p : deposito.listar()) {
            System.out.println("  - " + p);
        }
    }
}
