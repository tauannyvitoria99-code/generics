package logistica;

import java.time.LocalDate;

/** Demonstração da solução com Generics (Parte II). */
public class Main {
    public static void main(String[] args) {
        // 2b) três depósitos tipados
        Deposito<Eletronico> depEletronicos = new Deposito<>("Eletrônicos");
        Deposito<Alimento> depAlimentos = new Deposito<>("Alimentos");
        Deposito<Vestuario> depVestuario = new Deposito<>("Vestuário");

        depEletronicos.adicionar(new Eletronico("Notebook", 4500.00, 220));
        depEletronicos.adicionar(new Eletronico("Smartphone", 2300.00, 110));
        depAlimentos.adicionar(new Alimento("Arroz 5kg", 29.90, LocalDate.of(2027, 1, 10)));
        depVestuario.adicionar(new Vestuario("Camiseta", 59.90, "M"));

        // 2c) IMPOSSÍVEL guardar Alimento em Deposito<Eletronico> -> não compila:
        // depEletronicos.adicionar(new Alimento("Arroz 5kg", 29.90, LocalDate.of(2027, 1, 10)));
        //   erro: incompatible types: Alimento cannot be converted to Eletronico
        // Deposito<String> invalido = new Deposito<>("X");
        //   erro: type argument String is not within bounds of type-variable T

        // 2d) retirada SEM cast
        System.out.println("== 2d) Retirada sem cast");
        Eletronico e = depEletronicos.retirar().orElseThrow();   // nenhum (Eletronico) aqui
        System.out.println("Retirado: " + e + " | voltagem = " + e.getVoltagem() + "V");

        // 1d) Optional em vez de null
        System.out.println("== 1d) Depósito vazio devolve Optional.empty()");
        Deposito<Vestuario> vazio = new Deposito<>("Vazio");
        vazio.retirar().ifPresentOrElse(
                v -> System.out.println("Retirado: " + v),
                () -> System.out.println("Depósito '" + vazio.getNome() + "' está vazio (sem null, sem NPE)."));

        // 3a) método genérico buscarPorNome
        System.out.println("== 3a) buscarPorNome");
        Operacoes.buscarPorNome(depEletronicos, "smartphone")
                .ifPresent(p -> System.out.println("Encontrado: " + p));
        System.out.println("Busca por 'Geladeira': "
                + Operacoes.buscarPorNome(depEletronicos, "Geladeira").isPresent());

        // 3b) transferir com PECS: Deposito<Eletronico> -> Deposito<Produto>
        System.out.println("== 3b) transferir (PECS)");
        Deposito<Produto> depGeral = new Deposito<>("Geral (Produto)");
        int movidos = Operacoes.transferir(depEletronicos, depGeral);
        System.out.println("Itens transferidos: " + movidos);
        movidos = Operacoes.transferir(depAlimentos, depGeral);
        System.out.println("Itens transferidos: " + movidos);

        // 3c) listarConteudo com Deposito<?>
        System.out.println("== 3c) listarConteudo (Deposito<?>)");
        Operacoes.listarConteudo(depGeral);
        Operacoes.listarConteudo(depVestuario);
        Operacoes.listarConteudo(depEletronicos);

        // Transferir eletrônicos para depósito de alimentos? Não compila:
        // Operacoes.transferir(depEletronicos, depAlimentos);
        //   erro: no suitable method found for transferir(Deposito<Eletronico>,Deposito<Alimento>)
    }
}
