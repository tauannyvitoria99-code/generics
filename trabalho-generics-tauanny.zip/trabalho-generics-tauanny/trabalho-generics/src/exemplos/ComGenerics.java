package exemplos;

import java.util.ArrayList;
import java.util.List;

/** Parte I, questões 2 e 3: exemplos executáveis de Generics. */
public class ComGenerics {

    // 2c) classe genérica
    static class Caixa<T> {
        private T conteudo;
        void guardar(T conteudo) { this.conteudo = conteudo; }
        T abrir() { return conteudo; }
    }

    // 2c) método genérico
    static <T> T primeiro(List<T> lista) {
        return lista.get(0);
    }

    // 3b) bounded type
    static <T extends Comparable<T>> T maior(T a, T b) {
        return a.compareTo(b) >= 0 ? a : b;
    }

    // 3d) PECS: produtor => extends
    static double somar(List<? extends Number> numeros) {
        double soma = 0;
        for (Number n : numeros) soma += n.doubleValue();
        return soma;
    }

    // 3d) PECS: consumidor => super
    static void preencherComInteiros(List<? super Integer> destino) {
        for (int i = 1; i <= 3; i++) destino.add(i);
    }

    // 3d) wildcard ilimitado
    static void imprimir(List<?> lista) {
        for (Object o : lista) System.out.print(o + " ");
        System.out.println();
    }

    public static void main(String[] args) {
        System.out.println("--- 2c) Classe e método genéricos");
        Caixa<String> caixa = new Caixa<>();     // diamond (Java 7)
        caixa.guardar("Olá");
        String s = caixa.abrir();                // sem cast
        var numeros = new ArrayList<Integer>();  // var (Java 10)
        numeros.add(10);
        numeros.add(20);
        System.out.println("Caixa: " + s + " | primeiro(): " + primeiro(numeros));

        System.out.println("--- 3a) Type Erasure");
        List<String> ls = new ArrayList<>();
        List<Integer> li = new ArrayList<>();
        System.out.println("ArrayList<String>.class == ArrayList<Integer>.class ? "
                + (ls.getClass() == li.getClass()));

        System.out.println("--- 3b) Bounded types");
        System.out.println("maior(3, 7) = " + maior(3, 7));
        System.out.println("maior(\"banana\", \"abacaxi\") = " + maior("banana", "abacaxi"));

        System.out.println("--- 3c) Arrays são covariantes; List é invariante");
        Object[] arr = new String[1];            // compila (covariância)
        try {
            arr[0] = 123;                        // erro só em execução
        } catch (ArrayStoreException e) {
            System.out.println("Array: " + e);
        }
        // List<Object> lo = new ArrayList<String>();   // NÃO compila (ver evidencias/)

        System.out.println("--- 3d) Wildcards e PECS");
        List<Double> doubles = List.of(1.5, 2.5);
        System.out.println("somar(List<Double>) = " + somar(doubles));
        List<Number> destino = new ArrayList<>();
        preencherComInteiros(destino);           // List<Number> aceita Integer
        System.out.print("destino (List<Number>) = ");
        imprimir(destino);
    }
}
