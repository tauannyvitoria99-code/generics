package exemplos;

import java.util.ArrayList;
import java.util.List;

/** Parte I, questão 1c: coleção sem Generics + cast + ClassCastException. */
public class SemGenerics {
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void main(String[] args) {
        List lista = new ArrayList();      // raw type: guarda Object
        lista.add("Java");                 // String
        lista.add(42);                     // Integer (autoboxing)
        lista.add(3.14);                   // Double

        for (int i = 0; i < lista.size(); i++) {
            // O compilador aceita: sem Generics, o cast é "confiança" do programador.
            String texto = (String) lista.get(i);
            System.out.println("Elemento " + i + ": " + texto);
        }
    }
}
