<?php
require_once __DIR__ . '/config/config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    $conn->close();
    header('Location: index.php?status=nao_encontrado');
    exit;
}

// bind_result() é usado no lugar de get_result() para funcionar mesmo sem mysqlnd.
$stmt = $conn->prepare('SELECT nome, telefone FROM contatos WHERE id = ?');
if (!$stmt) {
    $erroMsg = htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
    $conn->close();
    die('Erro ao preparar consulta: ' . $erroMsg);
}
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->bind_result($nomeBanco, $telefoneBanco);
if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    header('Location: index.php?status=nao_encontrado');
    exit;
}
$stmt->close();

$contato = ['nome' => $nomeBanco, 'telefone' => $telefoneBanco];
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar'])) {
    $nome = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if ($nome === '' || $telefone === '') {
        $erro = 'Preencha todos os campos.';
    } elseif (tamanhoTexto($nome) > 100 || tamanhoTexto($telefone) > 20) {
        $erro = 'O nome deve ter até 100 caracteres e o telefone até 20.';
    } else {
        // Uso solicitado no exercício: escapar os dados antes do UPDATE.
        $nomeSeguro = mysqli_real_escape_string($conn, $nome);
        $telefoneSeguro = mysqli_real_escape_string($conn, $telefone);
        $idSeguro = (int)$id;
        $sql = "UPDATE contatos SET nome = '$nomeSeguro', telefone = '$telefoneSeguro' WHERE id = $idSeguro";

        if ($conn->query($sql)) {
            $conn->close();
            header('Location: index.php?status=atualizado');
            exit;
        }
        $erro = 'Não foi possível atualizar: ' . $conn->error;
    }

    $contato['nome'] = $nome;
    $contato['telefone'] = $telefone;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar contato</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<main class="container narrow">
    <section class="card">
        <h1>Editar contato</h1>
        <?php if ($erro !== ''): ?><p class="alert error"><?= htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
        <form method="POST" action="editar.php?id=<?= (int)$id ?>">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" maxlength="100" required value="<?= htmlspecialchars($contato['nome'], ENT_QUOTES, 'UTF-8') ?>">
            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" maxlength="20" required value="<?= htmlspecialchars($contato['telefone'], ENT_QUOTES, 'UTF-8') ?>">
            <button type="submit" name="atualizar">Salvar alterações</button>
            <a class="back" href="index.php">Voltar</a>
        </form>
    </section>
</main>
</body>
</html>
<?php $conn->close(); ?>
