-- Execute este arquivo no phpMyAdmin ou no console SQL do IntelliJ caso queira criar o banco manualmente.
-- ATENÇÃO NO INTELLIJ IDEA: Não clique em "Scripted Extensions -> Generate POJOs.groovy"!
-- Para rodar este SQL no IntelliJ, clique com o botão direito e escolha "Run 'aula_php.sql'",
-- ou simplesmente abra o projeto PHP no navegador, pois o config.php já cria o banco e a tabela automaticamente.

CREATE DATABASE IF NOT EXISTS aula_php
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE aula_php;

CREATE TABLE IF NOT EXISTS contatos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
