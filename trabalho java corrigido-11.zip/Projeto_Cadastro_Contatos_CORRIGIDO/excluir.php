<?php
require_once __DIR__ . '/config/config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    $conn->close();
    header('Location: index.php?status=nao_encontrado');
    exit;
}

$stmt = $conn->prepare('DELETE FROM contatos WHERE id = ?');
if (!$stmt) {
    $erroMsg = htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
    $conn->close();
    die('Erro ao preparar exclusão: ' . $erroMsg);
}

$stmt->bind_param('i', $id);
if (!$stmt->execute()) {
    $erroMsg = htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8');
    $stmt->close();
    $conn->close();
    die('Erro ao excluir contato: ' . $erroMsg);
}

$excluiu = $stmt->affected_rows > 0;
$stmt->close();
$conn->close();

if ($excluiu) {
    header('Location: index.php?status=excluido');
} else {
    header('Location: index.php?status=nao_encontrado');
}
exit;
