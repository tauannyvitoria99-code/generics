<?php
// Desativa exceções automáticas do mysqli (padrão no PHP 8.1+) para tratar erros manualmente.
mysqli_report(MYSQLI_REPORT_OFF);

// Configuração do MySQL (padrão do XAMPP).
$host = 'localhost';
$port = 3306;
$user = 'root';
$pass = '';
$db   = 'aula_php';

// Função auxiliar compatível mesmo quando a extensão mbstring está desativada no PHP (comum no IntelliJ/Windows).
function tamanhoTexto(string $texto): int {
    if (function_exists('mb_strlen')) {
        return mb_strlen($texto, 'UTF-8');
    }
    return strlen($texto);
}

// Verifica se a extensão mysqli está habilitada.
if (!extension_loaded('mysqli')) {
    die('Erro: a extensão mysqli não está habilitada no PHP. Ative "extension=mysqli" no seu arquivo php.ini e reinicie o servidor/Apache.');
}

// Tenta conectar via localhost e, caso falhe no Windows/IntelliJ, tenta automaticamente via 127.0.0.1.
$conn = @new mysqli($host, $user, $pass, '', $port);
if ($conn->connect_error) {
    $conn = @new mysqli('127.0.0.1', $user, $pass, '', $port);
}

if ($conn->connect_error) {
    die('Não foi possível conectar ao MySQL. Confira se o MySQL está iniciado no XAMPP e se usuário/senha estão corretos. Detalhe: ' . htmlspecialchars($conn->connect_error, ENT_QUOTES, 'UTF-8'));
}

if (!$conn->set_charset('utf8mb4')) {
    die('Não foi possível configurar UTF-8: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}

// Cria o banco e a tabela automaticamente, caso ainda não existam.
$sqlBanco = "CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if (!$conn->query($sqlBanco)) {
    die('Não foi possível criar o banco aula_php: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}

if (!$conn->select_db($db)) {
    die('Não foi possível selecionar o banco aula_php: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}

$sqlTabela = "CREATE TABLE IF NOT EXISTS contatos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (!$conn->query($sqlTabela)) {
    die('Não foi possível criar a tabela contatos: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}
