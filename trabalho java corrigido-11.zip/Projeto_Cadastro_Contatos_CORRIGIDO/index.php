<?php
require_once __DIR__ . '/config/config.php';

$status = $_GET['status'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adicionar'])) {
    $nome = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if ($nome === '' || $telefone === '') {
        $conn->close();
        header('Location: index.php?status=campos');
        exit;
    }

    if (tamanhoTexto($nome) > 100 || tamanhoTexto($telefone) > 20) {
        $conn->close();
        header('Location: index.php?status=limite');
        exit;
    }

    // O exercício solicita mysqli_real_escape_string() antes do INSERT.
    $nomeSeguro = mysqli_real_escape_string($conn, $nome);
    $telefoneSeguro = mysqli_real_escape_string($conn, $telefone);
    $sql = "INSERT INTO contatos (nome, telefone) VALUES ('$nomeSeguro', '$telefoneSeguro')";

    if ($conn->query($sql)) {
        $conn->close();
        header('Location: index.php?status=adicionado');
        exit;
    }

    $erroMsg = htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
    $conn->close();
    die('Erro ao cadastrar contato: ' . $erroMsg);
}

$resultado = $conn->query('SELECT id, nome, telefone FROM contatos ORDER BY id DESC');
if (!$resultado) {
    $erroMsg = htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
    $conn->close();
    die('Erro ao listar contatos: ' . $erroMsg);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Contatos</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<main class="container">
    <h1>Cadastro de Contatos</h1>

    <?php if ($status === 'adicionado'): ?>
        <p class="alert success">Contato cadastrado com sucesso!</p>
    <?php elseif ($status === 'atualizado'): ?>
        <p class="alert success">Contato atualizado com sucesso!</p>
    <?php elseif ($status === 'excluido'): ?>
        <p class="alert success">Contato excluído com sucesso!</p>
    <?php elseif ($status === 'nao_encontrado'): ?>
        <p class="alert error">Contato não encontrado ou já excluído.</p>
    <?php elseif ($status === 'campos'): ?>
        <p class="alert error">Preencha todos os campos.</p>
    <?php elseif ($status === 'limite'): ?>
        <p class="alert error">Confira o tamanho dos campos informados (nome até 100 e telefone até 20 caracteres).</p>
    <?php endif; ?>

    <section class="card">
        <h2>Adicionar contato</h2>
        <form method="POST" action="index.php">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" maxlength="100" required>
            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" maxlength="20" required>
            <button type="submit" name="adicionar">Adicionar contato</button>
        </form>
    </section>

    <section class="card">
        <h2>Contatos cadastrados</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>ID</th><th>Nome</th><th>Telefone</th><th>Ações</th></tr>
                </thead>
                <tbody>
                <?php if ($resultado->num_rows === 0): ?>
                    <tr><td colspan="4" class="empty">Nenhum contato cadastrado.</td></tr>
                <?php else: ?>
                    <?php while ($linha = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?= (int)$linha['id'] ?></td>
                            <td><?= htmlspecialchars($linha['nome'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($linha['telefone'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td class="actions">
                                <a class="edit" href="editar.php?id=<?= (int)$linha['id'] ?>">Editar</a>
                                <a class="delete" href="excluir.php?id=<?= (int)$linha['id'] ?>" onclick="return confirm('Deseja realmente excluir este contato?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
</body>
</html>
<?php
$resultado->free();
$conn->close();
?>
