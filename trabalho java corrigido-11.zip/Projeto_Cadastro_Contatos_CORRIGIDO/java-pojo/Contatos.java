package com.exemplo.contatos;

import java.io.Serializable;

/**
 * Classe POJO gerada a partir da tabela `contatos` (banco `aula_php`).
 * Incluída caso você estivesse executando o "Generate POJOs.groovy" no IntelliJ IDEA
 * para obter a entidade Java correspondente à tabela SQL.
 */
public class Contatos implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String nome;
    private String telefone;

    public Contatos() {
    }

    public Contatos(Long id, String nome, String telefone) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "Contatos{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", telefone='" + telefone + '\'' +
                '}';
    }
}
