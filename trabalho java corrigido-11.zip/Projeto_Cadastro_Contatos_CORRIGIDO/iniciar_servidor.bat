@echo off
chcp 65001 >nul
echo =========================================================
echo   INICIANDO PROJETO CADASTRO DE CONTATOS (PHP + MySQL)
echo =========================================================
echo.

if exist "C:\xampp\php\php.exe" (
    echo [OK] PHP do XAMPP encontrado em C:\xampp\php\php.exe
    echo Certifique-se de que o MySQL esta iniciado no XAMPP Control Panel!
    echo Abrindo navegador em http://localhost:8000 ...
    start "" "http://localhost:8000"
    "C:\xampp\php\php.exe" -S localhost:8000
    goto :eof
)

where php >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] PHP encontrado no PATH do Windows.
    echo Certifique-se de que o MySQL esta rodando!
    echo Abrindo navegador em http://localhost:8000 ...
    start "" "http://localhost:8000"
    php -S localhost:8000
    goto :eof
)

echo [AVISO] O executavel do PHP nao foi encontrado no PATH.
echo Se voce usa o XAMPP, copie esta pasta para:
echo   C:\xampp\htdocs\Projeto_Cadastro_Contatos_CORRIGIDO
echo E acesse no navegador:
echo   http://localhost/Projeto_Cadastro_Contatos_CORRIGIDO/
pause
