PROJETO: CADASTRO DE CONTATOS - VERSÃO CORRIGIDA (COMPATÍVEL COM INTELLIJ IDEA E XAMPP)

================================================================================
POR QUE ACONTECEU O ERRO "Generate POJOs.groovy / Unsupported class file major version 70"?
================================================================================
1. O que significa "major version 70":
   No Java, cada versão do JDK possui um número interno de versão de bytecode:
   - Java 17 = 61
   - Java 21 = 65
   - Java 25 = 69
   - Java 26 = 70
   O seu IntelliJ IDEA está configurado com o JDK 26 (major version 70), mas o motor interno
   do Groovy do IntelliJ (usado pelo script "Generate POJOs.groovy") ainda não suporta o
   bytecode do Java 26 e trava na fase "semantic analysis".

2. Por que o "Generate POJOs.groovy" foi chamado:
   O script "Generate POJOs.groovy" é uma ferramenta do banco de dados do IntelliJ que serve
   apenas para criar classes Java (.java) a partir de tabelas SQL. Quando você clica em "Run"
   no IntelliJ com essa configuração selecionada (ou clica em Scripted Extensions -> Generate POJOs),
   o IntelliJ tenta rodar esse script Groovy em vez de abrir seu projeto PHP.

3. Como corrigir no seu IntelliJ IDEA em 3 passos:
   - PASSO 1 (Mudar o JDK do projeto para 21 ou 17 LTS):
     No IntelliJ, pressione Ctrl+Alt+Shift+S (File -> Project Structure -> Project) e mude o
     campo "SDK" de 26 para Java 21 (ou Java 17).
   - PASSO 2 (Remover a execução do Generate POJOs.groovy):
     No topo direito do IntelliJ (ao lado do botão verde de Play/Run), clique no menu de
     configurações -> "Edit Configurations...", selecione "Generate POJOs.groovy" na aba Groovy
     e clique no botão "-" (Delete) para removê-lo.
   - PASSO 3 (Executar o projeto PHP corretamente):
     Use a configuração "Iniciar Servidor PHP (localhost:8000)" já incluída neste projeto,
     ou dê dois cliques em "iniciar_servidor.bat" (com o MySQL ativo no XAMPP), ou coloque a
     pasta em C:\xampp\htdocs\Projeto_Cadastro_Contatos_CORRIGIDO e acesse:
     http://localhost/Projeto_Cadastro_Contatos_CORRIGIDO/

   OBS: Caso você realmente quisesse a classe Java POJO da tabela `contatos`, ela já foi
   gerada e incluída na pasta `java-pojo/Contatos.java`!

================================================================================
CORREÇÕES APLICADAS NO CÓDIGO PHP
================================================================================
1. Compatibilidade sem mbstring (config/config.php, index.php, editar.php):
   Adicionada a função `tamanhoTexto()` que usa `mb_strlen()` se disponível ou faz fallback
   automático para `strlen()`, evitando Fatal Error quando o PHP roda pelo IntelliJ sem mbstring.
2. Fallback automático localhost / 127.0.0.1 (config/config.php):
   Caso a conexão via `localhost` falhe no Windows/IntelliJ por resolução de socket/IPv6, o
   código tenta conectar automaticamente via `127.0.0.1:3306`.
3. Validação real na exclusão (excluir.php e index.php):
   Verifica `$stmt->affected_rows > 0` antes de exibir mensagem de sucesso e fecha conexões
   corretamente antes de cada redirecionamento (`header('Location: ...')`).
4. Configuração pronta para o IntelliJ (.idea e iniciar_servidor.bat):
   Configurado para JDK 21 LTS por padrão e com atalho de execução para subir o servidor PHP.
